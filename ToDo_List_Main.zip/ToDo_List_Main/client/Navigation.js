/* JSON FILE OF ITEMS IN TODO_LIST*/ 
let ToDo_List_JSON = 
[
    {
        "user": "Patrick",
        "creation_date": { "day": 25, "month": 11, "year": 2022},
        "deadline":{ "day": 30, "month": 11, "year": 2022},
        "toDo": "Geburtstageinladungen verschicken.",
        "completed": false
    },

    {
        "user": "Sarah",
        "creation_date": { "day": 23, "month": 11, "year": 2022},
        "deadline":{ "day": 27, "month": 11, "year": 2022},
        "toDo": "Zimmer aufräumen.",
        "completed": false
    },

    {
        "user": "Neo",
        "creation_date": { "day": 10, "month": 11, "year": 2022},
        "deadline":{ "day": 20, "month": 11, "year": 2022},
        "toDo": "Für Franzprüfung lernen.",
        "completed": false 
    }
]


/* GET ELEMENTS */
const main_content = document.getElementById("main_content")

const navigation_create = document.getElementById("navigation_create")
const navigation_list = document.getElementById("navigation_list")
const start_content = document.getElementById("start_content")
const create_content = document.getElementById("create_content")
        const ToDo_form = document.getElementById("ToDo_form")
const list_content = document.getElementById("list_content")

const list_table = document.getElementById("list_table")
const list_table_header = document.getElementById("list_table_header")
const list_tbody = document.getElementById("list_tbody")
var table_created=false


/* DISPLAY PAGE: CREATE TODO*/
navigation_create.addEventListener("click", displayCreate)
    function displayCreate()
    {
        if(issue == false ||issue == true) {

        create_content.style =""
        ToDo_form.style=""
        start_content.style = "display: none;"
        list_content.style = "display: none;"
        list_table.style = "display: none;"
        list_table_header.style = "display: none;"
        } else {
            alert("Please Log In at first")
        }
    
    }



/* DISPLAY PAGE: YOUR TODO LIST*/
navigation_list.addEventListener("click", displayList)

function displayList()
{
    if(issue == false ||issue == true) {

    
    list_content.style =""
    list_table.style=""
    list_table_header.style=""
    ToDo_form.style= "display: none;"
    start_content.style = "display: none;"
    create_content.style = "display: none;"
    if (table_created==false)
    {
    createToDo_Table(ToDo_List_JSON)
    }
}else{
    alert("Please Log In at first")

}
    
}

/* FUNCTION FOR CREATING A TABLE */
function createToDo_Table(data)
{

    for (var i = 0; i < data.length; i++)
    {
        var table_row = `<tr> 
                            <td>
                                ${data[i].user}
                            </td>
                            <td>
                                ${data[i].creation_date.day}.
                                ${data[i].creation_date.month}.
                                ${data[i].creation_date.year}
                            </td>
                            <td>
                                ${data[i].toDo}
                            </td>

        </tr>`

        list_tbody.innerHTML += table_row
        table_created=true
    }
}


var issue;
var loggedIn;
var msg;
const LoginBtn = document.getElementById("button");

LoginBtn.addEventListener("click", (e) => {
  e.preventDefault();
  const login = "http://localhost:3000/login";
  const Username_text = document.getElementById("username").value;
  const Password_text = document.getElementById("password").value;
  fetch(login, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      username: Username_text,
      password: Password_text,
    }),
  })
    .then((response) => response.json())
    .then((data) => {
      issue = data.err;
      loggedIn = data.login;
      msg = data.msg;
    })
    .then(() => {
      if (issue == false || loggedIn == true) {
        alert(msg)
      } else if (issue == true || loggedIn == false) {
        alert(msg)
      }
    })
    .catch((err) => {
      console.log(err);
    });
});

const value_User = document.getElementById(value_User)
const value_Date = document.getElementById(value_Date)
const value_ToDo = document.getElementById(value_ToDo)

const input_username = document.getElementById(input_username).value
const input_date = document.getElementById(input_date).value
const input_ToDo = document.getElementById(input_ToDo).value

const submit_bt = document.getElementById(submit_bt)

submit_bt.addEventListener("click", add_ToDo)
function add_ToDo()
{
    value_User.innerText= input_username 
    value_Date.innerText= input_date
    value_ToDo.innerText= input_ToDo
}



